'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class TamilMonthMaster extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  }
  TamilMonthMaster.init({
    tamil_month_name: DataTypes.STRING
  }, {
    sequelize,
    modelName: 'TamilMonthMaster',
  });
  return TamilMonthMaster;
};